const KEY='siyomaTenantTrackerV1';
let data=JSON.parse(localStorage.getItem(KEY)||'null')||{tenants:[],payments:[]};
const money=n=>'KSh '+Number(n||0).toLocaleString('en-KE');
const save=()=>{localStorage.setItem(KEY,JSON.stringify(data));renderAll()};
const todayISO=()=>new Date().toISOString().slice(0,10);
document.getElementById('today').textContent=new Date().toLocaleDateString('en-KE',{day:'numeric',month:'short',year:'numeric'});
document.getElementById('tDue').value=todayISO();document.getElementById('pDate').value=todayISO();

function showScreen(id){document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active');document.querySelectorAll('nav button').forEach(x=>x.classList.toggle('active',x.dataset.screen===id));renderAll()}
function openModal(id){if(id==='paymentModal')populateTenantSelect();document.getElementById(id).classList.add('show')}
function closeModal(id){document.getElementById(id).classList.remove('show')}
function tenantPaid(t){return data.payments.filter(p=>p.tenantId===t.id).reduce((a,p)=>a+Number(p.amount),0)}
function tenantBalance(t){return Math.max(0,Number(t.rent)-tenantPaid(t))}
function renderDashboard(){
 const expected=data.tenants.reduce((a,t)=>a+Number(t.rent),0), collected=data.payments.reduce((a,p)=>a+Number(p.amount),0);
 const outstanding=data.tenants.reduce((a,t)=>a+tenantBalance(t),0);
 document.getElementById('unitsCount').textContent=data.tenants.length;
 document.getElementById('occupiedCount').textContent=data.tenants.length;
 document.getElementById('vacantCount').textContent=0;
 document.getElementById('expected').textContent=money(expected);
 document.getElementById('collected').textContent=money(collected);
 document.getElementById('outstanding').textContent=money(outstanding);
 const list=document.getElementById('outstandingList'); const due=data.tenants.filter(t=>tenantBalance(t)>0);
 list.className='list '+(!due.length?'empty':'');
 list.innerHTML=due.length?due.map(t=>itemHTML(t)).join(''):'No outstanding balances.';
}
function itemHTML(t){let b=tenantBalance(t);return `<div class="item"><div><b>${esc(t.name)}</b><div class="meta">Unit ${esc(t.unit)} · Due ${t.due}</div></div><div class="amount ${b?'balance':'paid'}">${money(b)}<div class="meta">${b?'Balance':'Paid'}</div></div></div>`}
function renderTenants(){const q=(document.getElementById('tenantSearch').value||'').toLowerCase();let arr=data.tenants.filter(t=>(t.name+' '+t.unit).toLowerCase().includes(q));document.getElementById('tenantList').innerHTML=arr.length?arr.map(itemHTML).join(''):'<div class="panel">No tenants found.</div>'}
function renderUnits(){const list=document.getElementById('unitList');list.innerHTML=data.tenants.length?data.tenants.map(t=>`<div class="item"><div><b>🏠 Unit ${esc(t.unit)}</b><div class="meta">${esc(t.name)}</div></div><div class="amount">${money(t.rent)}<div class="meta">per month</div></div></div>`).join(''):'<div class="panel">No units added yet.</div>'}
function renderPayments(){const list=document.getElementById('paymentList');list.innerHTML=data.payments.length?[...data.payments].reverse().map(p=>{let t=data.tenants.find(x=>x.id===p.tenantId);return `<div class="item"><div><b>💳 ${esc(t?t.name:'Deleted tenant')}</b><div class="meta">Unit ${esc(t?t.unit:'-')} · ${p.date}</div></div><div class="amount paid">${money(p.amount)}</div></div>`}).join(''):'<div class="panel">No payments recorded yet.</div>'}
function populateTenantSelect(){let s=document.getElementById('pTenant');s.innerHTML=data.tenants.length?data.tenants.map(t=>`<option value="${t.id}">${esc(t.name)} — Unit ${esc(t.unit)}</option>`).join(''):'<option value="">Add a tenant first</option>'}
document.getElementById('tenantForm').onsubmit=e=>{e.preventDefault();data.tenants.push({id:Date.now().toString(),name:tName.value.trim(),phone:tPhone.value.trim(),unit:tUnit.value.trim(),rent:Number(tRent.value),due:tDue.value});save();e.target.reset();tDue.value=todayISO();closeModal('tenantModal');showScreen('tenants')};
document.getElementById('paymentForm').onsubmit=e=>{e.preventDefault();if(!data.tenants.length)return;data.payments.push({id:Date.now().toString(),tenantId:pTenant.value,amount:Number(pAmount.value),date:pDate.value});save();e.target.reset();pDate.value=todayISO();closeModal('paymentModal');showScreen('payments')};
function clearData(){if(confirm('Delete all tenants and payment records?')){data={tenants:[],payments:[]};save();showScreen('dashboard')}}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function renderAll(){renderDashboard();renderTenants();renderUnits();renderPayments()}
renderAll();showScreen('dashboard');